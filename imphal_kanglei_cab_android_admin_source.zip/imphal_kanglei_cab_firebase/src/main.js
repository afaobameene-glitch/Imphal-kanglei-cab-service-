import "./style.css";
import { auth, db, firebaseConfigured } from "./firebase.js";
import { signInWithEmailAndPassword, onAuthStateChanged, signOut } from "firebase/auth";
import {
  collection, doc, getDoc, setDoc, updateDoc, addDoc, serverTimestamp,
  onSnapshot, query, orderBy, limit
} from "firebase/firestore";
import { Geolocation } from "@capacitor/geolocation";
import { Capacitor } from "@capacitor/core";

const BASE=100, PER_KM=35, PER_WAIT=2.5, MAX_ACCURACY=25, MAX_SPEED=120;
const app=document.querySelector("#app");
let user=null, profile=null, trip=null, watchId=null, tickId=null, lastFix=null;
let distance=0, waitingMs=0, startedAt=0, lastTick=0, manual=false, manualKm=0, forceWait=false;
let unsubTrips=null, unsubDrivers=null, tripsCache=[], driversCache=[];
const money=n=>"₹"+Math.round(n).toLocaleString("en-IN");
const km=n=>Number(n||0).toFixed(2);
const time=ms=>{let s=Math.floor(ms/1000);return [Math.floor(s/3600),Math.floor(s%3600/60),s%60].map(x=>String(x).padStart(2,"0")).join(":")};
const fare=(d,w)=>Math.round(BASE+Math.max(0,d)*PER_KM+Math.max(0,w)*PER_WAIT);
const waitMins=()=>waitingMs/60000;
const liveDistance=()=>manual?manualKm:distance;
const h=(a,b)=>{const r=x=>x*Math.PI/180, d1=r(b.lat-a.lat),d2=r(b.lng-a.lng),x=Math.sin(d1/2)**2+Math.cos(r(a.lat))*Math.cos(r(b.lat))*Math.sin(d2/2)**2;return 6371*2*Math.asin(Math.sqrt(x));};
function shell(content){app.innerHTML=`<header><div class="brand"><span class="brandicon">🚕</span><div><b>Imphal Kanglei Cab Service</b><small>Driver & Owner Platform</small></div></div>${user?'<button id="logout" class="ghost">Log out</button>':''}</header><main>${content}</main>`;document.querySelector("#logout")?.addEventListener("click",logout);}
function loginView(){shell(`<section class="panel login"><h1>Welcome</h1><p>Sign in to continue to your cab service account.</p><label>Email</label><input id="email" type="email" placeholder="name@example.com"><label>Password</label><input id="password" type="password" placeholder="Password"><button id="login" class="primary full">Sign in</button><p class="muted" id="message">${firebaseConfigured?"Use the account created in Firebase Authentication.":"Firebase setup required: edit src/firebase.js first."}</p></section>`);document.querySelector("#login").onclick=async()=>{const msg=document.querySelector("#message");try{await signInWithEmailAndPassword(auth,$("#email").value.trim(),$("#password").value);}catch(e){msg.textContent=e.message;}};}
const $=s=>document.querySelector(s);
async function logout(){stopTracking();await signOut(auth);}
function driverView(){
 const active=!!trip;
 shell(`<section class="status"><span class="pill">${active?"TRIP IN PROGRESS":"READY"}</span><span>${profile?.name||user.email}</span></section>
 <section class="panel"><h2>Trip meter</h2><div class="metrics"><div><small>Distance</small><strong id="km">${km(liveDistance())}</strong><small>km</small></div><div><small>Elapsed</small><strong id="elapsed">00:00:00</strong><small>HH:MM:SS</small></div><div><small>Waiting</small><strong id="wait">${waitMins().toFixed(1)}</strong><small>minutes</small></div><div><small>Estimated fare</small><strong id="estimate">${money(fare(liveDistance(),waitMins()))}</strong><small>INR</small></div></div>
 <p class="muted" id="gpsstatus">GPS not started</p><div id="alert" class="alert hidden"></div>
 <div id="manualbox" class="hidden"><label>Total trip distance (km)</label><input id="manualkm" type="number" min="0.01" step="0.01" placeholder="Enter trip kilometres"><button id="savekm" class="secondary full">Use manual distance</button></div>
 <div class="buttons"><button id="start" class="primary" ${active?"disabled":""}>Start Trip</button><button id="end" class="end" ${active?"":"disabled"}>End Trip</button></div>
 <button id="waitbtn" class="secondary full" ${active?"":"disabled"}>${forceWait?"Stop marked waiting":"Mark waiting"}</button>
 </section>
 <section class="panel"><h3>Fare rates</h3><div class="row"><span>Base fare</span><b>₹100</b></div><div class="row"><span>Distance</span><b>₹35 / km</b></div><div class="row"><span>Waiting</span><b>₹2.50 / min</b></div></section>
 <p class="muted tiny">Allow location permission and keep location enabled. GPS tracking requires an internet connection to sync trips. Use manual distance only if GPS is unavailable.</p>`);
 $("#start").onclick=startTrip;$("#end").onclick=endTrip;
 $("#waitbtn").onclick=()=>{forceWait=!forceWait;$("#waitbtn").textContent=forceWait?"Stop marked waiting":"Mark waiting";};
 $("#savekm").onclick=()=>{let n=Number($("#manualkm").value);if(!Number.isFinite(n)||n<=0){alert("Enter a positive distance.");return;}manualKm=n;manual=true;refreshMeter();$("#alert").textContent=`Manual distance saved: ${km(n)} km`;};
 if(trip) startClock();
}
function refreshMeter(){if(!$("#km"))return;$("#km").textContent=km(liveDistance());$("#wait").textContent=waitMins().toFixed(1);$("#estimate").textContent=money(fare(liveDistance(),waitMins()));$("#elapsed").textContent=time(Date.now()-startedAt);}
async function startTrip(){
 if(!firebaseConfigured){alert("Firebase is not configured. Follow README setup first.");return;}
 distance=0;waitingMs=0;startedAt=Date.now();lastTick=startedAt;lastFix=null;manual=false;manualKm=0;forceWait=false;
 const ref=await addDoc(collection(db,"trips"),{driverUid:user.uid,driverName:profile?.name||user.email,status:"ON_TRIP",distanceKm:0,waitingMinutes:0,baseFare:BASE,totalFare:BASE,startAt:serverTimestamp(),createdAt:serverTimestamp()});
 trip={id:ref.id};driverView();$("#gpsstatus").textContent="Requesting high accuracy GPS…";$("#alert").classList.add("hidden");
 tickId=setInterval(tick,1000);
 try{
  if(Capacitor.isNativePlatform()){
   const perm=await Geolocation.checkPermissions();
   if(perm.location!=="granted"&&perm.coarseLocation!=="granted")await Geolocation.requestPermissions();
   watchId=await Geolocation.watchPosition({enableHighAccuracy:true,timeout:15000,maximumAge:0},onFix,onGpsError);
  }else{
   if(!navigator.geolocation)throw new Error("Geolocation not supported");
   watchId=navigator.geolocation.watchPosition(onFix,onGpsError,{enableHighAccuracy:true,maximumAge:0,timeout:15000});
  }
 }catch(e){fallback(e.message);}
}
function onFix(pos,err){
 if(err){fallback(err.message||"GPS unavailable");return;}
 const c=pos.coords||pos,accuracy=Number(c.accuracy);
 if(!Number.isFinite(accuracy)||accuracy>MAX_ACCURACY){if($("#gpsstatus"))$("#gpsstatus").textContent="Waiting for accurate GPS (25m or better)…";return;}
 const lat=Number(c.latitude),lng=Number(c.longitude),stamp=pos.timestamp||Date.now();
 if(!Number.isFinite(lat)||!Number.isFinite(lng))return;
 let speed=(Number.isFinite(c.speed)&&c.speed>=0)?c.speed*3.6:null;
 const fix={lat,lng,timestamp:stamp,speedKmh:speed};
 if(lastFix){
  const delta=h(lastFix,fix),secs=Math.max(1,(stamp-lastFix.timestamp)/1000),implied=delta/secs*3600;
  if(implied>MAX_SPEED)return;
  if(speed===null)speed=implied;
  if(delta>0.0005)distance+=delta;
 }else if(speed===null)speed=0;
 fix.speedKmh=speed;lastFix=fix;
 if($("#gpsstatus"))$("#gpsstatus").textContent=`GPS active · accuracy ${Math.round(accuracy)}m`;
 refreshMeter();
 updateDoc(doc(db,"trips",trip.id),{distanceKm:distance,waitingMinutes:waitMins(),currentLocation:{lat,lng,updatedAt:serverTimestamp()}}).catch(console.error);
 setDoc(doc(db,"users",user.uid),{location:{lat,lng,updatedAt:serverTimestamp()},isOnline:true},{merge:true}).catch(console.error);
}
function onGpsError(e){fallback(e?.message||"GPS permission or signal unavailable");}
function fallback(reason){
 stopWatch();manual=true;
 if($("#alert")){$("#alert").classList.remove("hidden");$("#alert").textContent="GPS unavailable. Switch to manual mode. "+reason;}
 if($("#manualbox"))$("#manualbox").classList.remove("hidden");
 if($("#gpsstatus"))$("#gpsstatus").textContent="Manual distance mode";
}
function tick(){
 if(!trip)return;
 const delta=Math.max(0,Date.now()-lastTick);lastTick=Date.now();
 if(forceWait||(lastFix&&lastFix.speedKmh<5))waitingMs+=delta;
 refreshMeter();
}
function stopWatch(){
 if(watchId!==null){if(Capacitor.isNativePlatform())Geolocation.clearWatch({id:watchId}).catch(()=>{});else navigator.geolocation?.clearWatch(watchId);}
 watchId=null;
}
async function endTrip(){
 if(!trip)return;
 tick();
 if(manual&&(!Number.isFinite(manualKm)||manualKm<=0)){alert("GPS is unavailable. Enter total trip kilometres and tap Use manual distance before ending.");$("#manualbox").classList.remove("hidden");return;}
 const d=liveDistance(),w=waitMins(),total=fare(d,w),duration=Date.now()-startedAt;
 if(!manual&&d<=0){alert("No GPS distance was recorded. Check location permission or use manual distance.");return;}
 stopTracking();
 await updateDoc(doc(db,"trips",trip.id),{status:"COMPLETED",distanceKm:d,waitingMinutes:w,durationSeconds:Math.round(duration/1000),distanceFare:d*PER_KM,waitingFare:w*PER_WAIT,totalFare:total,paymentStatus:"UNPAID",endAt:serverTimestamp(),currentLocation:null});
 setDoc(doc(db,"users",user.uid),{isOnline:false},{merge:true});
 const doneId=trip.id;trip=null;
 shell(`<section class="panel"><div class="success">✓ Trip completed</div><h2>Fare receipt</h2><div class="row"><span>Base fare</span><b>₹100</b></div><div class="row"><span>Distance (${km(d)} km)</span><b>${money(d*PER_KM)}</b></div><div class="row"><span>Waiting (${w.toFixed(1)} min)</span><b>${money(w*PER_WAIT)}</b></div><div class="row"><span>Duration</span><b>${time(duration)}</b></div><div class="grand"><small>Grand total</small><strong>${money(total)}</strong></div><label>Payment method</label><select id="pay"><option>Cash</option><option>UPI</option></select><button id="paid" class="primary full">Confirm payment received</button><button id="again" class="secondary full">Start new trip</button><p class="muted" id="paymsg">Trip saved to owner dashboard.</p></section>`);
 $("#paid").onclick=async()=>{await updateDoc(doc(db,"trips",doneId),{paymentMethod:$("#pay").value,paymentStatus:"PAID"});$("#paymsg").textContent="Payment marked as received.";};
 $("#again").onclick=()=>{distance=0;waitingMs=0;startedAt=0;manual=false;driverView();};
}
function stopTracking(){stopWatch();if(tickId)clearInterval(tickId);tickId=null;}
function startClock(){if(tickId)clearInterval(tickId);tickId=setInterval(()=>{tick();},1000);}
function adminView(){
 shell(`<section class="status"><span class="pill">OWNER ADMIN</span><span>${profile?.name||user.email}</span></section>
 <section class="metrics summary"><div><small>Trips loaded</small><strong>${tripsCache.length}</strong></div><div><small>Completed revenue</small><strong>${money(tripsCache.filter(t=>t.status==="COMPLETED").reduce((s,t)=>s+(t.totalFare||0),0))}</strong></div><div><small>Drivers</small><strong>${driversCache.length}</strong></div><div><small>Running trips</small><strong>${tripsCache.filter(t=>t.status==="ON_TRIP").length}</strong></div></section>
 <section class="panel"><h2>Drivers</h2><div id="drivers">${driverRows()}</div></section>
 <section class="panel"><h2>Recent trips</h2><div id="trips">${tripRows()}</div></section>
 <p class="muted tiny">Live updates arrive from drivers while their app is online and has location permission.</p>`);
}
function driverRows(){return driversCache.length?driversCache.map(d=>`<div class="item"><div><b>${esc(d.name||d.email||d.id)}</b><small>${d.isOnline?"Online":"Offline"} · ${d.email||""}</small></div>${d.location?`<a target="_blank" href="https://maps.google.com/?q=${d.location.lat},${d.location.lng}">View map ↗</a>`:"<small>No location</small>"}</div>`).join(""):"<p class='muted'>No driver profiles yet. Create driver accounts and user profiles in Firebase using README instructions.</p>";}
function tripRows(){return tripsCache.length?tripsCache.map(t=>`<div class="item"><div><b>${esc(t.driverName||"Driver")}</b><small>${t.status} · ${km(t.distanceKm)} km · ${Number(t.waitingMinutes||0).toFixed(1)} min wait</small><small>${t.startAt?.toDate?t.startAt.toDate().toLocaleString():"Recently"}</small></div><b>${money(t.totalFare??fare(t.distanceKm||0,t.waitingMinutes||0))}</b></div>`).join(""):"<p class='muted'>No trips recorded yet.</p>";}
function esc(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function subscribeAdmin(){
 unsubDrivers?.();unsubTrips?.();
 unsubDrivers=onSnapshot(collection(db,"users"),snap=>{driversCache=snap.docs.map(d=>({id:d.id,...d.data()})).filter(x=>x.role==="driver");if($("#drivers"))$("#drivers").innerHTML=driverRows();if($("#app")){const old=$("#drivers");if(!old)adminView();}});
 unsubTrips=onSnapshot(query(collection(db,"trips"),orderBy("createdAt","desc"),limit(100)),snap=>{tripsCache=snap.docs.map(d=>({id:d.id,...d.data()}));if($("#trips")){$("#trips").innerHTML=tripRows();const summary=$("#app .summary");if(summary){summary.innerHTML=`<div><small>Trips loaded</small><strong>${tripsCache.length}</strong></div><div><small>Completed revenue</small><strong>${money(tripsCache.filter(t=>t.status==="COMPLETED").reduce((s,t)=>s+(t.totalFare||0),0))}</strong></div><div><small>Drivers</small><strong>${driversCache.length}</strong></div><div><small>Running trips</small><strong>${tripsCache.filter(t=>t.status==="ON_TRIP").length}</strong></div>`;}}});
}
onAuthStateChanged(auth,async u=>{
 user=u;
 if(!u){profile=null;unsubDrivers?.();unsubTrips?.();loginView();return;}
 try{
  const snap=await getDoc(doc(db,"users",u.uid));
  if(!snap.exists()){await signOut(auth);alert("Your account has no user profile. Ask the owner to create a driver/admin profile in Firestore.");return;}
  profile=snap.data();
  if(profile.role==="admin"){adminView();subscribeAdmin();}
  else if(profile.role==="driver"){driverView();}
  else{await signOut(auth);alert("Account role is not configured.");}
 }catch(e){shell(`<section class="panel"><h2>Account setup error</h2><p>${esc(e.message)}</p></section>`);}
});
