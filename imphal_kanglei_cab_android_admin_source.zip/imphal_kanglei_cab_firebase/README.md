# Imphal Kanglei Cab Service — Android + Owner Admin starter

This is a cloud-buildable Capacitor Android project. It contains one app with role-based screens:
- Driver: GPS trip meter, automatic distance, waiting time, fare receipt, payment status.
- Owner admin: live driver online/location list, recent trips, completed revenue.

## 1. Create / configure Firebase (required before building)

A Gmail account alone is not enough: create a Firebase project and register a **Web app** in it.

1. Open https://console.firebase.google.com/ and create a project.
2. Add a Web app, copy its Firebase config.
3. In **Authentication → Sign-in method**, enable **Email/Password**.
4. In **Firestore Database**, create a database (production mode).
5. Paste the config values into `src/firebase.js`, replacing all `PASTE_...` values.
6. In Firestore → Rules, publish the contents of `firestore.rules`.

## 2. Create owner account and profile

1. In Firebase Authentication → Users → Add user, create the owner's email/password login.
2. Copy the owner's UID.
3. In Firestore, create collection `users`, document ID = owner's UID.
4. Add fields:
   - `role` (string) = `admin`
   - `name` (string) = `Cab Service Owner`
   - `email` (string) = owner's login email

## 3. Create driver accounts

For each driver:
1. Add an Email/Password user in Firebase Authentication.
2. Copy that driver's UID.
3. Create `users/{driverUID}` in Firestore with:
   - `role` (string) = `driver`
   - `name` (string) = driver's display name
   - `email` (string) = driver's login email
   - `isOnline` (boolean) = `false`

Drivers sign in with the credentials you create. The app does not include public self-registration.

## 4. Build APK from an Android phone using GitHub Actions

You do not need Android Studio on the phone. You do need a GitHub account.
1. Create a new **private** GitHub repository.
2. Upload all files/folders from this project (including `.github/workflows/android-apk.yml`).
3. Commit to branch `main`.
4. In GitHub, open **Actions → Build Android APK → Run workflow** (or wait for the first push build).
5. Open the completed workflow run → Artifacts → download `imphal-kanglei-cab-debug-apk`.
6. Extract the ZIP and install `app-debug.apk` on the Android phone. If Android asks, allow installation from that browser/file manager.

The debug APK is for testing/internal distribution. A Play Store or production release requires a signed release build and protected signing key.

## 5. Test GPS

- Enable Location on the phone.
- Allow location permission for the app.
- Test outdoors with a clear view of the sky.
- The filter rejects fixes with accuracy worse than 25 metres and implausible movement above 120 km/h.
- GPS distance needs valid consecutive fixes. If GPS fails, enter the trip distance manually.
- Keep the app open during the trip for this starter build. Android battery optimization/background tracking may stop updates if the app is backgrounded or killed.

## Fare formula

`Math.round(100 + distanceKm * 35 + waitingMinutes * 2.5)`

## Important production work still required

This is a starter build, not a finished audited fleet platform. Before real passenger use:
- Add a secure owner-only driver creation screen / Cloud Function (never expose Firebase Admin credentials in the app).
- Add stronger Firestore validation and App Check.
- Add signed release APK, privacy policy, consent, crash reporting, backup/export, and tested background location service.
- Test fare rounding, poor GPS, phone calls/backgrounding, and UPI payments with real devices.
- UPI QR/payment confirmation is not integrated in this starter; drivers can record Cash/UPI method and mark payment received.
